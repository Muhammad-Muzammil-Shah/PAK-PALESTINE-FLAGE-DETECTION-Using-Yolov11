# Free Palestine > 2024-12-22 6:44pm
https://universe.roboflow.com/mohammad-muzammil-shah-wpk02/free-palestine

Provided by a Roboflow user
License: CC BY 4.0

